Community
=========

The official mailing list is hosted on `Google Groups (gevent)`_. To
subscribe via email, send a message to
gevent+subscribe@googlegroups.com. Here's what people are saying now:


.. raw:: html

   <iframe id="forum_embed"
         src="javascript:void(0)"
         scrolling="no"
         frameborder="0"
         width="100%"
         height="500">
   </iframe>

   <script type="text/javascript">
         document.getElementById("forum_embed").src = "https://groups.google.com/forum/embed/?place=forum/gevent"
             + "&showsearch=true&showtabs=false&hideforumtitle=true&showpopout=true&parenturl=" + encodeURIComponent(window.location.href);
   </script>


You're also welcome to join `#gevent`_ IRC channel on freenode.


Russian group
-------------

Русскоязычная группа находится здесь: `Google Groups (gevent-ru)`_. Чтобы подписаться, отправьте сообщение на gevent-ru+subscribe@googlegroups.com


.. _Google Groups (gevent): http://groups.google.com/group/gevent
.. _#gevent: http://webchat.freenode.net/?channels=gevent
.. _Google Groups (gevent-ru): http://groups.google.com/group/gevent-ru
