:mod:`errors` -- Exceptions raised by the :mod:`gridfs` package
=================================================================

.. automodule:: gridfs.errors
   :synopsis: Exceptions raised by the gridfs package
   :members:
